import { useState } from 'react'
import './App.css'
import './style.css'
import CustomerList from './Components/CustomerList'
import CustomerForm from './Components/CustomerForm'
import CustomerPayments from './Components/CustomerPayments'
import PaymentForm from './Components/PaymentForm'

function App() {
  const [selectedCustomer, setSelectedCustomer] = useState(null)
  const [showForm, setShowForm] = useState(false)

  return (
    <div className="app">
      <header className="app-header">
        <h1>Ügyfelkezelő</h1>
      </header>

      <main className="app-main">
        <div className="customer-section">
          <h2>Ügyfelek</h2>
          <button onClick={() => setShowForm(!showForm)}>
            Új ügyfél
          </button>

          {showForm && <CustomerForm onSuccess={() => setShowForm(false)} />}

          <CustomerList onSelectCustomer={setSelectedCustomer} />
        </div>

        {selectedCustomer && (
          <div className="payments-section">
            <CustomerPayments customer={selectedCustomer} />
            <PaymentForm customerId={selectedCustomer.azon} onSuccess={() => {}} />
          </div>
        )}
      </main>
    </div>
  )
}

export default App
