import { useState } from 'react';

function PaymentForm({ customerId, onSuccess }) {
  const [ugyfel_azon, setUgyfelAzon] = useState(customerId);
  const [datum, setDatum] = useState('');
  const [osszeg, setOsszeg] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    fetch('http://localhost:8000/api/newPayment', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ugyfel_azon, datum, osszeg }),
    })
    .then(() => {
      setDatum('');
      setOsszeg('');
      onSuccess();
    });
  };

  return (
    <div className="payment-form">
      <h3>Új befizetés</h3>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Ügyfél azonosító:</label>
          <input type="number" value={ugyfel_azon} onChange={(e) => setUgyfelAzon(e.target.value)} />
        </div>

        <div className="form-group">
          <label>Dátum:</label>
          <input type="date" value={datum} onChange={(e) => setDatum(e.target.value)} />
        </div>

        <div className="form-group">
          <label>Összeg:</label>
          <input type="number" value={osszeg} onChange={(e) => setOsszeg(e.target.value)} />
        </div>

        <button type="submit">Mentés</button>
      </form>
    </div>
  );
}

export default PaymentForm;
