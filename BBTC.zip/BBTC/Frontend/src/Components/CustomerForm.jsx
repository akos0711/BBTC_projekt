import { useState } from 'react';

function CustomerForm({ onSuccess }) {
  const [nev, setNev] = useState('');
  const [szulev, setSzulev] = useState('');
  const [irszam, setIrszam] = useState('');
  const [orsz, setOrszag] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    fetch('http://localhost:8000/api/newUser', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nev, szulev, irszam, orsz }),
    })
    .then(res => res.json())
    .then(() => {
      setNev('');
      setSzulev('');
      setIrszam('');
      setOrszag('');
      onSuccess();
    });
  };

  return (
    <div className="customer-form">
      <h2>Ügyfél hozzáadása</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Név:</label>
          <input type="text" value={nev} onChange={(e) => setNev(e.target.value)} />
        </div>

        <div className="form-group">
          <label>Születési év:</label>
          <input type="text" value={szulev} onChange={(e) => setSzulev(e.target.value)} />
        </div>

        <div className="form-group">
          <label>Irányítószám:</label>
          <input type="number" value={irszam} onChange={(e) => setIrszam(e.target.value)} />
        </div>

        <div className="form-group">
          <label>Ország:</label>
          <input type="text" value={orsz} onChange={(e) => setOrszag(e.target.value)} />
        </div>

        <button type="submit">Mentés</button>
      </form>
    </div>
  );
}

export default CustomerForm;
