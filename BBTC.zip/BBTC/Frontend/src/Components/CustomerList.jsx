import { useState, useEffect } from 'react';

function CustomerList({ onSelectCustomer }) {
  const [customers, setCustomers] = useState([]);

  useEffect(() => {
    fetch('http://localhost:8000/api/users')
      .then(res => res.json())
      .then(data => setCustomers(data));
  }, []);

  if (customers.length === 0) return <div>Betöltés...</div>;

  return (
    <div>
      <table>
        <thead>
          <tr>
            <th>Név</th>
            <th>Év</th>
            <th>Irányítószám</th>
            <th>Ország</th>
            <th>Befizetések</th>
          </tr>
        </thead>
        <tbody>
          {customers.map((customer) => (
            <tr key={customer.azon}>
              <td>{customer.nev}</td>
              <td>{customer.szulev}</td>
              <td>{customer.irszam}</td>
              <td>{customer.orsz}</td>
              <td>
                <button onClick={() => onSelectCustomer(customer)}>
                  Megnyit
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default CustomerList;
