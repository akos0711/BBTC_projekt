import { useState, useEffect } from 'react';

function CustomerPayments({ customer }) {
  const [payments, setPayments] = useState([]);

  useEffect(() => {
    if (customer) {
      fetch(`http://localhost:8000/api/customerPayment?id=${customer.azon}`)
        .then(res => res.json())
        .then(data => setPayments(data));
    }
  }, [customer]);

  const handleDelete = (id) => {
    if (confirm('Biztosan törölni szeretnéd ezt a befizetést?')) {
      fetch(`http://localhost:8000/api/deletePayment?id=${id}`, {
        method: 'DELETE',
      })
      .then(() => {
        setPayments(payments.filter(p => p.azon !== id));
      });
    }
  };

  return (
    <div className="customer-payments">
      <h2>{customer.nev} befizetései</h2>

      {payments.length === 0 ? (
        <p>Nincsenek befizetések</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Azonosító</th>
              <th>Dátum</th>
              <th>Összeg</th>
              <th>Törlés</th>
            </tr>
          </thead>
          <tbody>
            {payments.map((payment) => (
              <tr key={payment.azon}>
                <td>{payment.azon}</td>
                <td>{payment.datum}</td>
                <td>{payment.osszeg} Ft</td>
                <td>
                  <button onClick={() => handleDelete(payment.azon)}>Törlés</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default CustomerPayments;
