<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    protected $table = 'befiz';
    public $timestamps = false;

    public function ugyfel() {
        return $this->belongsTo(Customer::class, 'azon');
    }
}
