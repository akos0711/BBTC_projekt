<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    protected $table = 'ugyfel';
    public $timestamps = false;
    protected $primaryKey = 'azon';

    public function befiz() {
        return $this->hasMany(Payment::class, 'ugyfel_azon');
}
}
