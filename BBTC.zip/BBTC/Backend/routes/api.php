<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\CustomerController;

Route::get('/users', [CustomerController::class, 'index']);
Route::post('/newUser', [CustomerController::class, 'store']);
Route::post('/newPayment', [PaymentController::class, 'store']);
Route::delete('/deletePayment', [PaymentController::class, 'destroy']);
Route::get('/customerPayment', [CustomerController::class, 'show']);
Route::put('/updatePayment', [CustomerController::class, 'update']);